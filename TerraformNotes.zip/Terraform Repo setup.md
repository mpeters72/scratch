# Background
## Project Requirements and Terragrunt Configuration Structure

Currently, we have a repository containing Terragrunt configurations for all environments. The Terragrunt config is organized in a tree structure with two top-level folders: **live** and **nonlive**. Below these folders, there is a **CDS** folder containing a **risk** folder, which includes multiple folders for each environment. The cds/risk subfolders are a hangover from when the repo was previously shared between multiple delivery groups. Now that we have our own dedicated repository those folders are redundant

### Current Folder Structure Mapping

- The **live** and **nonlive** folders map directly to the two accounts we currently have:
    
    - **Live DAT
    - **Nonlive DAT**
    
- These folders simultaneously correspond to the two account types and the accounts themselves ie we have one production (live) account and one nonproduction (nonlive) account.

For example the prod mysql config lives under `live/cds/risk/prod/mysql-8` and Risk UI config is in `live/cds/risk/prod/cdsriskui`. Effectively this is `account_name_and_type/cds/risk/environment/role`
Account information is held under the `live` folder, project specific info is under `cds` and `risk`, environment specific info is under `prod` and role specific info is under `mysql-8`
Terragrunt is run from the `role` folder and inherits config about the environment and AWS account from the parent folders
There are around 5 prod environments, in the live DAT account and around 15 environments in the nonlive DAT
### New Requirements: DR Accounts

We are creating a **DR set of accounts** to enable failover in case of compromise with the current account. In the propsed DR solution setup, there will again be 2 account types, production and nonproduction, however, unlike the current setup, we will have multiple accounts with different functions. Some will have both standby and current versions and some will have only one version. This will include:
- DNS accounts - one each for prod and nonprod
- Restricted backup - single prod account spanning both standby and current
- Tooling accounts - one in standby, one in current. Each will contain a live and nonlive Jenkins responsible for deployments to production and nonproduction type accounts respectively
- Prod - in its own production accounts, one current, one standby
- Preprod - a production type account only present in standby which will contain standby versions of all of the production type environments from the live DAT account other than prod
- Dev/QA/Program envs will have a nonprod type account in current and standby
- AMI Build - single nonprod account
At any one time, users will only be able to access either the current set of accounts **OR** the standby, Not both simultaneously. This access will be controlled by SRS roles and AWS IAM roles as appropriate. SRS roles are tied to our existing GitLab tenancy. Only one set of SRS roles canm be associated with a Gitlab tenancy. We may therefore be required to have a second tenancy in order to have the appropriate access controls applied. This may therefore require splitting environment/pipeline config across 2 repositories with different access permissions in GitLab. However theis requirement is still TBC. 
The current accounts and the standby accounts will have dedicated tooling accounts associated with them. The current tooling (tooling1) will house Jenkins servers which are only able to connect to and deploy to the accounts housing the current environments. The standby tooling will house Jenkins servers which will only be able to connect and depoloy to the accounts in the standby infrastructure.
DNS accounts will span both current and standby
The restricted backup account will effectively be a standby account acting as a staging area for backups. Backuops will be trabsferred from current prod to the restricted backup account, then transferred to the standby prod account in a DR event so that tehy can be restored to the standby prod service in case of DR
### Problem with Existing Folder Structure

The existing structure cannot accommodate the new standby accounts because:

- The **live** and **non-live** folders are tied to specific accounts.
- Standby accounts will have multiple accounts of each type, making it impossible to map them directly into the current folder structure.

### Repository Structure Details

- The repo contains both **account-specific** and **environment-specific** configuration information.
- Example:
    
    - `live/cds/risk/prod/mysql-8` contains MySQL config for the live environment.
    
- In the standby scenario, the standby prod MySQL config cannot be placed in the same folder structure because the parent folders would contain account-specific information unique to the current account.

### Multiple tenancies/Repos
We may be required to separate code into multiple repos which may or may not live in different tenancies with different access permissions.
Accounts will have different config values so we will not want to sync current prod account values to the standby prod account config for example.
We will however need to sync certain values such as instance size, and numbers as such things will need to be the same in both accounts.
There are certain config values which are in the role terraform vars file, for example the IAM profiles in the mysql config, which may differ between the equivalent environments in current and standby so we need to handle that case when syncing. This may require splitting into multiple config files or moving the values "up the tree". This may have implications on ECM and how and where it writes config as it currently only writes to one specific file per role.

### Code Dependencies on Folder Structure

1. **Terraform Pipelines**:
    
    - Pull Terragrunt config based on the folder structure.
    - Use parent folders to extract account-specific information.
    
2. **ECM**:
    - Writes Terraform and terragrunt config from its own configuration files to `terragrunt.hcl` and `terraform.tfvars` files in the terraform repo.
    - Relies on folder structure to locate those files form the relevant environment
### Key Challenges

- The folder structure must remain consistent for code that reads/writes config files in order to minimise required code changes.
- If Standby accounts  require a different folder structure, that will potentially leading to compatibility issues.
- State files which are stored for every environment in the current gitlab terraform repo will need to be handled consistentl
- We need to achieve segregation of access to the different environment/account config
- Sync config between repos and/or gitlab tenancies where required
### Proposed Solution

- Create a **separate folder structure** alongside **live** and **non-live** for standby accounts (e.g., `standby/prod`).
- However, this would result in a **different folder structure** compared to the current accounts, which could cause issues for code that relies on the existing structure.

Placing folders within the current tree structure will mean that incorrect config is inherited from parent folders. This could be changed if we change the parameters passed to terragrunt but would probably be less than ideal as terraform for infrastructure in new accounts would have to be called with different parameters to that in current accounts.
We could create a new tree from the top level of the current repo, but that tree would have a different structure to the current account folder tree, again meaning that config for different accounts would have to be handled differently, leading to inconsistencies and possible problems 
### Summary of Current Setup

We have a repo called **terraform** that contains **terragrunt**  and **terraform** config. This repo is set up to reflect our current environments. The current setup includes two accounts: **nonlive** and **live**.
#### New Requirements

We need to consider how to handle more accounts. The plan is to:

- Replicate our current nonproduction and production accounts

- Create a set of **standby accounts** that is completely separate with its own permissions

- Have the ability to manage additional production and non-production accounts which will be required to host services required to provide capabilities required by the DR work
#### Key Considerations

1. **State Files**: Determine how to handle state files for different accounts, potenttiaslly accross different repos with different permissions /access privileges

2. **Config Management**: Address how to consistently manage config for all new accounts

3. **Code Changes**:

	- Update **pipeline scripts/libraries** that call Terraform
	- Modify **ECM** such that it can still create environment config
	- Possibly ECM will need to output the same changes to multiple envs ie equivalent standby and current

4. **GitLab Repo Split** (details of requirements TBC):
	- Split into 2 repos in order to allow for granular permissions/access to config 
	- Potentially house the 2 GitLab repos into two tenancies
		- which may require current accounts in the existing tenancy and standby in a new tenancy 
	- Depending upon how this split is, config may need to be kept up-to-date in multiple locartions which will require some kind of sync and/or ECM will need to update multiple locations (however this may transgress permissions boundaries)
#### Permission Segregation

- Users accessing current accounts vs. standby accounts must be segregated
- No simultaneous access to current and standby accounts
- Possible solutions:
	- Split tenancy in GitLab
	- Avoid splitting tenancy in GitLab (evaluate both options)

#### Additional Notes

- There will be multiple standby production type accounts, one for prod alone and another for the other prod-like environments such as preprod
- The current setup only manages two accounts, so the new approach must scale to handle multiple accounts
- The repo structure and permissions need to be re-evaluated to ensure proper segregation and access control
- The repo structure should be consistent so as to not require differences in how code or pipelines handle current and standby config
## Option 1
Keep to the existing structure and add a new folder (and relevant subfolders) for each of the new accounts 
Or keep the current repo as is and create a new repo(s) just for standby and new accounts 
### Current Setup Overview

The current Terraform repo structure maps to the existing account setup with two top-level folders: `live` and `non-live`, corresponding to live and non-live DAT accounts. Each folder contains subfolders `cds/risk`, remnants from the previous shared repo. These directories don't cause an issue, however, they now serve no functional purpose but remain as part of the structure.
### Challenges with New Accounts

1. **Mapping Issues**:
	- The existing structure assumes one live account and one non-live account.
	- New requirements involve multiple live and non-live accounts, breaking the current mapping

2. **Folder Structure Complexity**:
- Configurations are embedded in the folder hierarchy, with values inherited from parent folders.
- Subfolders, `live` and `non-live` contain unique configurations for specific accounts (ie the live and nonlive DAT accounts).

1. **Proposed Solutions**:
- **Option 1a**: Add new accounts to the current structure.
	- Problem: Config values in the parent folders will be incorrect for the new accounts.
- **Option 1b**: Place new accounts at the top level.
		- Problem: Breaks the folder structure used by pipeline libraries and expected by ECM. Inconsistent structure between current and standby
- **Option 1c**: Keep the current repo as-is and create a new repo for the standby and new accounts. 
	- Advantage: Better segregation
	- Problem: Breaks the folder structure used by pipeline libraries and expected by ECM. Inconsistent structure between current and standby

4. **Code and Pipeline Implications**:
- Conditional logic in code handles environment-specific configurations (e.g., between current and standby).
- Introducing a second folder structure for standby accounts would create inconsistencies and complicate pipelines 
- Is only really an option if it is easy to implement however, even though it keeps close to the current way of working it still requires code changes to handle the inconsistencies  
### Conclusion
The existing folder structure is tightly coupled with configuration logic, making modifications risky. Alternative approaches require careful consideration to avoid introducing complexity or breaking existing workflows.
## Option 2
Reorganise the folder structure to match the proposed account structure

The second approach is to create a new folder structure which will represent the account setup for both the current accounts and the standby accounts. So this will have two folders at the top level, the same as we have currently, but these will be probably best renamed to `production` and `non-production` so they'll replace the live and non-live folders which we have currently. But these top-level folders rather than representing the account names as they do currently, they'll represent the account type (or security domain) of which there are two types: production and non-production. Then below that we'll have subfolders the actual accounts.

So in the production side, that will have subfolders for the current prod DAT account, the standby prod, and both of the tooling accounts as well as the other production accounts like the restricted backup account. And then under the `non-prod` folder, we'll have the existing non-live account, so the non-live data account, and then the new standby non-live or dev account. And also the non-live DNS account will go in there.

And then as we have now, we'll have subfolders for each of the environments. We'll also, if we go this structure, we'll remove the CDS and RISC subfolders because they're no longer required. So we'll still essentially have the same number of subfolders. The tree structure will still be as deep as it is currently. They'll just be different folders in terms of the required code changes.

Proposed structure will be `account_type/account_name/environment/role`

Examples:
current prod mysql:
`production/current-prod/prod/mysql-8`
Standby prod mysql:
`production/standby-prod/prod/mysql-8`
current preprod mysql:
`production/current-prod/preprod/mysql-8`
Standby preprod mysql:
`production/preprod/preprod/mysql-8`
Current tooling nonlive jenkins:
`production/tooling1/nonlive/jenkins`
Standby tooling live jenkins:
`production/tooling2/live/jenkins`

There will be changes needed to ECM and also changes needed to the pipelines which run the terraform. However, those changes will be largely restricted to a change in the paths where things live. There won't be any functional changes. Things will just live in different places.

## Advantages and Disadvantages

**Advantages**
- Consistency across current and standby accounts under the same folder structure
- Simplified management of account types (production vs. non-production) as security domains
- Sync between tenancies if required should be straight forward as can just sync everything (see below about lack of segregation though)

**Disadvantages**
- Potential need to split configuration into multiple files for environments requiring different settings 
- Code changes in ECM to handle multiple files instead of a single file 
- Lack of segregation between current and standby account configurations, leading to potential access issues
- Duplication across GitLab tenancies if required to have 2 tenancies

## Option 3
Same as Option 2 but split the repo into 2 repos, current and standby.

The third option is essentially option 2 refined. The only difference is that we split the repo into two. So, we have one repo for the current config and a second repo containing all standby accounts. The two repos, will both follow the same structure outlined in option 2 above

As with Option2 the folder structure differs from the current setup but remains largely in line with our current methodology. The key change is removing all standby accounts and placing them in their own repo 

These repos can exist within the current GitLab tenancy or, if required, in two separate tenancies (one for current infrastructure and the other for standby). This solves the segregation issue from option 2, allowing different permissions for each repo. However, it introduces a new problem: accounts with only one instance (e.g., DNS account, restricted backup account) will potentially need their config to exist in both repos, depending upon if or how we are required to set up the two tenancies. This will lead to duplicated code or config files which will both need maintaining/syncing. While not ideal, this duplication is manageable 

A potential issue arises if the same account remains in use before and after a DR even (as is the case with the DNS accounts or the restricted backup DNS). The Terraform state file currently resides in the terraform GitLab repo. If the requirement is to have two tenancies and we decide to have the config replicated to both tenancies such that so during a DR incident we run terraform only from the standby tenancy, we would need to make sure the state file is available and up-to-date by syncing/migrating it between tenancies. This could cause problems. Alternatively we could maintain a single copy of the config of such accounts in one or other of the tenancies. However, this could lead to issues regards access to the repo, ie thiongs in standby having access to the repo containing current config which violates the security boundary between the current and standby infrastructure.

---

### Advantages and Disadvantages

**Advantages:**

- **Segregation:** Repos can have different permissions, improving security and access control 
- **Scalability:** Separating current and standby accounts simplifies management and reduces conflicts in shared repos.
- Consustent: config is consistent across all accounts

**Disadvantages:**

- **Duplication:** Single-instance accounts (e.g., DNS, restricted backup) require duplicated config files across repos, leading to potential inconsistencies
- **State Sync Challenges:** Terraform state files must be synchronized during DR scenarios, risking conflicts if state files are not properly replicated between repos 
- **Access Limitations:** If using separate tenancies, standby tenancies may lack access to critical configs in the current repo, hindering Terraform execution

## Option 4
Decouple account and environment config by separating into different repos.

### Introduction

The fourth option involves restructuring the terragrunt configuration to address challenges in managing account and environment-specific configurations. This approach separates account-level and environment-level configurations into distinct repositories, enabling more streamlined management and replication processes.

### Approach Details

Rather than consolidating account and environment configurations into a single folder structure, this method proposes two distinct repositories:

1. **Account Repositories**: Each account will have its own repository containing configuration information required for terragrunt and terraform operations. These repos will not include environment-specific configurations, focusing solely on account-level settings.

2. **Environment Repositories**: A separate repository will house folders for each environment (e.g., prod, preprod). These folders will contain environment-specific configuration files in subfolders for the different roles, devoid of account-specific details. eg prod mysql will be in `prod/mysql-8`

The same config can be used for both the current and standby prod mysql by pulling account level config from the appropriate account repo. 

This structure simplifies replication by allowing account repos to reside in relevant GitLab repositories without duplication. Environment-level configurations can be replicated independently, as they lack account-specific data. For example, a single prod configuration folder can be reused across accounts by merging with account-specific settings, eliminating the need for separate prod configs for each account. State files will reside in account repos, avoiding conflicts in merged environments.

### Advantages

- **Simplified Replication**: Account repos can be managed independently, reducing the need for redundant replication of environment-specific data.

- **Scalability**: Separating account and environment configurations allows for easier management of multiple tenancies and accounts.

- **State File Management**: State files are isolated to account repos, minimizing conflicts during deployments.

- **Flexibility**: Environment configurations (e.g., prod) can be reused across accounts by dynamically merging with account-specific settings.
### Disadvantages

- **Complexity in Management**: Maintaining multiple repositories increases the overhead of coordination between account and environment configurations.
- **Potential for Errors**: Merging account-specific configurations with environment settings may introduce errors if not carefully managed.
- In accounts which remain the same before and after DR event (eg DNS and restricted backup) there may be the same issues as optikon 3 above around which tenancy the repo should live in and access. Maybe we can allow read-only access between tenancies for the repos which require it
- **Initial Setup Effort**: Separating configurations into distinct repos requires significant initial setup and organization.